var x = /Android|iPhone|iPad/i.test(navigator.userAgent);

if (x == true) {
    console.log(x)
    window.open("Mobile.html", "_self");   
}
else if (x == false) {
    console.log(x)
    window.open("Desktop.html", "_self")
}
