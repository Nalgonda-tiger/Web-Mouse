// window.addEventListener('touchmove', function (e){
//     console.log(e)
// });

// import { Peer } from "peerjs";

// window.addEventListener("load", (event) =>{
    var peer = new Peer()
    var myStream;

    peer.on("open", function(id){
        document.getElementById("MyID").innerHTML = "This is my id: " + id;
        console.log(id)
    })
    // let localDescription = ''
    // const offerAccepter = new RTCPeerConnection();
    // const offerCreator = new RTCPeerConnection();
    // offerCreator.createOffer()
    // .then(offer => offerAccepter.setLocalDescription(new RTCSessionDescription(offer)))
    // .then(()=> offerAccepter.setRemoteDescription(offerCreator.localDescription))
    // .then(()=> offerAccepter.createAnswer())
    // .then(answer => offerAccepter.setLocalDescription(new RTCSessionDescription(answer)))
    // .then(() => offerCreator.setRemoteDescription(offerAccepter.localDescription))
let dataChannel = pc.createDataChannel("MyApp Channel");

dataChannel.addEventListener("open", (event) => {
  beginTransmission(dataChannel);
});
    document.getElementById("clickthing").addEventListener('click', (e)=> {
        var result = document.getElementById("inputbox");
        document.getElementById("messageplace").innerHTML = result.value;
    })


    // document.getElementById("call-peer").addEventListener('click', (e) => {
    //     let remotePeerID = document.getElementById("peerID");
    //     document.getElementById("show-peer").innerHTML = "connecting with" + remotePeerID;
    //     callPeer(remotePeerID);
    // })

    // function callPeer(id) {
    //     navigator.mediaDevices.getUserMedia({video:true, audio:true}).then((stream)=>{
    //         myStream = stream
    //         let call = peer.call(id, stream)
    //         call.on('stream', function(remoteStream){
    //             addRemoteVideo(remoteStream)
    //         })
    //     }).catch((err)=>{
    //         console.log(err + "cant get media access");
    //     })
    //     // document.getElementById("buttonchange").addEventListener("click", (e) => {
    //     let message = document.getElementById("change");
    //     console.log(message.value);

        
    // }

    // function addRemoteVideo(stream) {
    //     document.getElementById("remote-video")
    // }
// });