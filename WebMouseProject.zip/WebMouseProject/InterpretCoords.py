import pyautogui
import sys
from tkinter import *

jsX = float(sys.argv[1])
jsY = float(sys.argv[2])

pyautogui.moveTo(jsX, jsY)