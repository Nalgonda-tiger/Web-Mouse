// import PythonShell from "/python-shell"
// var pything = import("PythonShell")
// import { PythonShell } from "/python-shell"
var divSelectRoom = document.getElementById("selectRoom")
var divConsultingRoom = document.getElementById("consultingRoom")
var inputRoomNumber = document.getElementById("roomNumber")
var GoToYourRoomButton = document.getElementById("goRoom")
var localVideo = document.getElementById("localVideo")
var remoteVideo = document.getElementById("remoteVideo")
var h2callName = document.getElementById("callName")
var inputCallName = document.getElementById("inputCallName")
var Send_Data = document.getElementById("setName")


var roomNumber, localStream, remoteStream, rtcPeerConnection, isCaller, dataChannel, mousecoords, mousecoordsX, mousecoordsY;


var iceServers = {
    'iceServer': [
        { 'urls': 'stun:stun.l.google.com:19302' },
        { 'urls': 'stun:stun1.l.google.com:19302' }
    ]
}

var streamConstraints = {
    audio: true,
    video: true
}

var socket = io()

GoToYourRoomButton.onclick = () => {
    if (inputRoomNumber.value === '') {
        alert("please type a room name")
    } else {
        roomNumber = inputRoomNumber.value
        socket.emit('create or join', roomNumber)
        // divConsultingRoom.style.display = "block";
    }
}



// Send_Data.onclick = () => {
//     if (inputCallName.value === '') {
//         alert("please type a room name")
//     } else {
//         dataChannel.send(inputCallName.value)
//         h2callName.innerText = inputCallName.value
//     }
// }

socket.on('created', async function (room) {
    // localStream = await navigator.mediaDevices.getUserMedia(streamConstraints)
    // localVideo.srcObject = localStream
    isCaller = true
})
socket.on('joined', async function (room) {
    // localStream = await navigator.mediaDevices.getUserMedia(streamConstraints)
    // localVideo.srcObject = localStream
    socket.emit('ready', roomNumber)

})


socket.on('ready', async function (room) {
    if (isCaller) {
        rtcPeerConnection = new RTCPeerConnection(iceServers)
        rtcPeerConnection.onicecandidate = onIceCandidate
        dataChannel = rtcPeerConnection.createDataChannel(roomNumber)
        var sdp = await rtcPeerConnection.createOffer()
        rtcPeerConnection.setLocalDescription(sdp)
        socket.emit('offer', {
            type: 'offer',
            sdp: sdp,
            room: roomNumber,
        })
        // dataChannel.onmessage = event => { coordshtml.innerText = event.data }
    }
})

socket.on('offer', async function (event) {
    if (!isCaller) {
        rtcPeerConnection = new RTCPeerConnection(iceServers)
        rtcPeerConnection.onicecandidate = onIceCandidate
        rtcPeerConnection.setRemoteDescription(new RTCSessionDescription(event))
        rtcPeerConnection.ondatachannel = event => {
            dataChannel = event.channel
            dataChannel.onmessage = event => {
                h2callName.innerText = event.data, console.log(coordshtml)
                // coordshtml.innerHTML = mousecoords
                socket.emit('pycall', mousecoordsX, mousecoordsY)
                var options = {
                    mode: 'text',
                    pythonOptions: ['-u'],
                    args: [mousecoordsX, mousecoordsY]
                }
                PythonShell.run('InterpretCoords.py', options)
            }

        }
        var sdp = await rtcPeerConnection.createAnswer();
        rtcPeerConnection.setLocalDescription(sdp)
        socket.emit('answer', {
            type: 'answer',
            sdp: sdp,
            room: roomNumber
        })
    }
})

socket.on('candidate', function (event) {
    var candidate = new RTCIceCandidate({
        sdpMLineIndex: event.label,
        candidate: event.candidate.candidate,
        sdpMid: event.id,
    });
    console.log(candidate)
    rtcPeerConnection.addIceCandidate(candidate)
    //call function for the rest of the program here
    FindDeviceType()
})

socket.on('answer', async function (event) {
    rtcPeerConnection.setRemoteDescription(new RTCSessionDescription(event))
})



// function onAddStream(event) {
//     remoteVideo.srcObject = event.streams[0]
//     remoteStream = event.streams[0]
// }

function onIceCandidate(event) {
    console.log('hello')
    if (event.candidate) {
        console.log('sending ice candidate', event.candidate)
        socket.emit('candidate', {
            type: 'candidate',
            label: event.candidate.sdpMLineIndex,
            id: event.candidate.sdpMid,
            candidate: event.candidate,
            room: roomNumber
        })
    }
}

function FindDeviceType() {
    var devicetype = /Android|iPhone|iPad/i.test(navigator.userAgent);
    var client_pc = 0, client_mobile = 0, newvalueformobile, newvalueforpc;
    var Mobileside = document.getElementById("TouchBoxCoords")
    var coordshtml = document.getElementById("coordshtml")


    if (devicetype == true) {
        newvalueformobile = client_mobile++
        Mobileside.style.height = screen.height + "px"
        Mobileside.style.width = screen.width + "px"

        var touchHandler = function (event) {
            var x = 0, y = 0;

            if (event.touches && event.touches[0]) {
                x = event.touches[0].clientX
                y = event.touches[0].clientY
            } else if (event.originalEvent && event.originalEvent.changedTouches[0]) {
                x = event.originalEvent.changedTouches[0].clientX
                y = event.originalEvent.changedTouches[0].clientY
            } else if (event.clientX && event.clientY) {
                x = event.clientX
                y = event.clientY
            }
            mousecoordsX = x
            mousecoordsY = y
            mousecoords = mousecoordsX + ',' + mousecoordsY
            dataChannel.send(mousecoords)
        }

        window.addEventListener('touchstart', touchHandler, false)
        window.addEventListener('touchmove', touchHandler, false)
    }
    else if (devicetype == false) {
        newvalueforpc = client_pc++
    }

    if (newvalueformobile == 2 || newvalueforpc == 2) {
        console.log("Hey! Don't Use two the same devices. If you are actually on mobile, then request a mobile website in the options given to you.")
    }
}