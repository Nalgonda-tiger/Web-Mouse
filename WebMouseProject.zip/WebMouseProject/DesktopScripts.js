var peer = new Peer()
var myStream;

document.getElementById("call-peer").addEventListener('click', (e) => {
    let remotePeerID = document.getElementById("peerID");
    document.getElementById("show-peer").innerHTML = "connecting with" + remotePeerID.value;
    callPeer(remotePeerID);
})


// get the peer id thing from the input
function callPeer(remotePeerID) {
    // peer.on('open', (remotePeerID) =>{

    //     console.log("Connected with Id: " + remotePeerID)
    // navigator.mediaDevices.getUserMedia({video:true, audio:true}).then((stream)=>{
    //     myStream = stream
    //     let call = peer.call(id, stream)
    //     call.on('stream', function(remoteStream){
    //         addRemoteVideo(remoteStream)
    //     })
    // }).catch((err)=>{
    //     console.log(err + "cant get media access");
    // })
    // document.getElementById("buttonchange").addEventListener("click", (e) => {

    
        let message = document.getElementById("change");
        console.log(message.value +" also connected with" + remotePeerID); 
    // })
  
}